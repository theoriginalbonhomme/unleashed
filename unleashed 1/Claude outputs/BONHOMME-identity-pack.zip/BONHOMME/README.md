# BONHOMME identity: production pack

Route B, The Wordmark. The name leads: Archivo Black set tight, with the two Ms fused onto one shared stem. The stencil face is the seal. BH is the short logo. Tagline: In service of art.

## Folders

| Folder | Contents |
| --- | --- |
| 00_colour | Palette as JSON, CSS variables and an SVG swatch strip |
| 01_logo | wordmark (primary), stacked (BON / HOMME), monogram (BH, the short logo), seal (the face), lockup (name + seal), tagline (name + In service of art.). Charcoal, off-white, yellow, pure black and pure white |
| 02_portrait | Master, silhouette, rough, fragmented and stencil-cut treatments, on turquoise and transparent; the original artwork |
| 03_pattern | The name as offset rows |
| 04_release | BNHM 001 (dub), 002 (acid/techno), 003 (microhouse/IDM) concepts and a 3000 px template with guides |
| 05_social | Spotify, YouTube, Instagram, SoundCloud templates and an A2 tour poster |
| 06_live | Four keyframes and bonhomme-live-visual.html (open in a browser, full screen; set BPM at the top of the script) |
| 07_merch | Print-ready artwork: T-shirt, hoodie, cap embroidery (BH), vinyl label, sticker, A3 laser-cut stencil, stage banner |
| 08_mockups | Flat product mockups and incorrect-use examples used in the guidelines |
| png | Every master exported: logos 4000 px wide (transparent), seals and square BH tiles 3000/1000/400 px, portraits 3000 px, release art 3000 × 3000 (also sRGB JPG), social at native size, live at 1920 × 1080 and 3840 × 2160 |
| 99_source | The scripts that build every file, for reference |

## Logo rules

- Primary: the wordmark. Never retype BONHOMME in a font; the fused MM exists only in the master files.
- Short logo: BH, for avatars, caps, labels and anywhere under 160 px wide.
- Seal: the face, secondary. With the name in the lockup, or alone as an avatar or sticker.
- Clear space: half the wordmark's cap height on every side.
- Minimum sizes: wordmark 160 px or 30 mm wide; lockup 200 px or 36 mm; stacked 96 px or 20 mm; BH 24 px or 6 mm tall; seal 32 px or 8 mm.

## What the files are

- Every SVG is true vector: shapes and outlined text, no embedded images and no live fonts. Files can go straight to a vinyl cutter, laser cutter or screen-print film.
- Print files are drawn in their real units (mm or inches). Add 3 mm bleed to the poster and sleeve at the printer's request.
- Colour in the files is RGB. Ask the printer to convert to CMYK (coated stock) and send a proof. Starting builds: Turquoise 78/0/24/0, Charcoal 65/60/60/75, Off-white 3/3/8/0, Riso Yellow 0/5/100/0.
- Release titles (DEEP WATER EP, ACID SIGNAL, MICRO / MACRO) and the gig dates on the poster and event post are placeholders.
- The magenta circle in the sticker file and the red lines in the stencil file are cut lines: keep them on their own layer.

## Specifications

| Deliverable | Format | Size | Colour |
| --- | --- | --- | --- |
| Logos, portraits | SVG + transparent PNG | PNG 4000 px wide | sRGB; CMYK at the printer |
| Release art | JPG or PNG | 3000 × 3000 px | sRGB |
| Spotify | PNG | header 2660 × 1140, avatar 750 px minimum | sRGB |
| YouTube | PNG | banner 2560 × 1440 (safe 1546 × 423), thumbnail 1280 × 720 | sRGB |
| Instagram | PNG | post 1080 × 1350, story 1080 × 1920 | sRGB |
| SoundCloud | PNG | header 2480 × 520, avatar 1000 px | sRGB |
| Tour poster | Vector | A2, 420 × 594 mm | CMYK, coated |
| Screen print | Vector, one ink | 12 × 4 in chest, 14 × 14 in back | Charcoal, matched by proof |
| Embroidery | SVG to the digitiser | BH 2.5 in wide | Thread to match |
| Vinyl label | Vector | 100 mm, 7.24 mm hole | CMYK |
| Live | PNG + HTML | 1920 × 1080 and 3840 × 2160 | sRGB |

## Fonts

All free under the SIL Open Font License (commercial use allowed), from Google Fonts: Archivo Black (the wordmark's base, already outlined, and headlines), Archivo (text), IBM Plex Mono (credits, catalogue numbers, the tagline).

## Naming

`bonhomme-[item]-[colour]-[size].[ext]`, for example `bonhomme-wordmark-charcoal-4000px.png`.
