"""Route B, The Wordmark: final BONHOMME marks as true-vector SVG masters."""
import os, json, shutil
import numpy as np
from lib import *
from geo import *

T, C, W, Y = '#00B8C7', '#242323', '#F2F0E9', '#FFE800'
FIN = os.path.join(HERE, 'final'); ROOT = os.path.join(FIN, 'BONHOMME')
for d in ['01_logo', '03_pattern']:
    shutil.rmtree(os.path.join(ROOT, d), ignore_errors=True)
shutil.rmtree(os.path.join(ROOT, 'png'), ignore_errors=True)
def out(rel, svg):
    p = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(svg)
def P(d, fill): return f'<path fill="{fill}" d="{d}"/>'
def tight(p):
    x0, y0, x1, y1 = bounds(p); return translate(p, -x0, -y0), x1 - x0, y1 - y0
inks = {'charcoal': C, 'offwhite': W, 'yellow': Y, 'black': '#000000', 'white': '#FFFFFF'}
AB = 'ArchivoBlack-Regular.ttf'

# wordmark: Archivo Black, tight, the double M fused onto one stem
wm, _, _ = wordmark_pp(AB, 'BONHOMME', 1000, -0.035, {5: -0.304})
wm, WW, WH = tight(wm); WD = to_d(wm)
for n, c in inks.items():
    out(f'01_logo/wordmark/bonhomme-wordmark-{n}.svg', svg_doc(round(WW, 1), round(WH, 1), P(WD, c), title='BONHOMME wordmark'))
# stacked: BON over HOMME, left aligned, line gap = 0.18 cap
bon, _, _ = wordmark_pp(AB, 'BON', 1000, -0.035, {}); bon, bw, bh = tight(bon)
homme, _, _ = wordmark_pp(AB, 'HOMME', 1000, -0.035, {2: -0.304}); homme, hw, hh = tight(homme)
gap = 0.18 * bh
st = union([bon, translate(homme, 0, bh + gap)]); st, SW, SH = tight(st); SD = to_d(st)
for n, c in inks.items():
    out(f'01_logo/stacked/bonhomme-stacked-{n}.svg', svg_doc(round(SW, 1), round(SH, 1), P(SD, c), title='BONHOMME stacked'))
# BH monogram: the short logo
bhp, _, _ = wordmark_pp(AB, 'BH', 1000, -0.035, {}); bhp, BW, BHH = tight(bhp); BD = to_d(bhp)
for n, c in inks.items():
    out(f'01_logo/monogram/bonhomme-bh-{n}.svg', svg_doc(round(BW, 1), round(BHH, 1), P(BD, c), title='BONHOMME short logo, BH'))
sq = max(BW, BHH) * 1.6
for n, bg, ink in [('charcoal-on-turquoise', T, C), ('charcoal-on-yellow', Y, C), ('offwhite-on-charcoal', C, W)]:
    out(f'01_logo/monogram/bonhomme-bh-{n}-square.svg', svg_doc(round(sq, 1), round(sq, 1), f'<path fill="{ink}" transform="translate({(sq-BW)/2:.1f},{(sq-BHH)/2:.1f})" d="{BD}"/>', bg=bg))

# the seal: the face, tight crop, no cut
ink = load_ink()
cx, cy, cs = 120, 60, 860
av = pp_from_d(trace(simplify(grow(ink[cy:cy+cs, cx:cx+cs], 3), blur=9, t=140), turdsize=900, alphamax=1.25), evenodd=True)
AVD = to_d(av)
for n, bg, c in [('turquoise', T, C), ('yellow', Y, C), ('charcoal', C, W)]:
    out(f'01_logo/seal/bonhomme-seal-{n}.svg', svg_doc(cs, cs, P(AVD, c), bg=bg, title='BONHOMME seal'))
out('01_logo/seal/bonhomme-seal-charcoal-transparent.svg', svg_doc(cs, cs, P(AVD, C)))

# lockup: wordmark + seal on the right, seal 1.5x cap tall, bottoms aligned
sealp, sw0, sh0 = tight(av)
ss = 1.5 * WH / sh0
lgap = 0.32 * WH
lock = union([wm, translate(sealp, WW + lgap, WH - sh0 * ss, ss)])
lock, LW, LH = tight(lock); LD = to_d(lock)
pad = 0.5 * WH
for n, bg, c in [('charcoal-on-turquoise', T, C), ('charcoal-on-yellow', Y, C), ('offwhite-on-charcoal', C, W), ('charcoal-on-offwhite', W, C)]:
    out(f'01_logo/lockup/bonhomme-lockup-{n}.svg', svg_doc(round(LW + 2*pad, 1), round(LH + 2*pad, 1), f'<g transform="translate({pad},{pad})">{P(LD, c)}</g>', bg=bg, title='BONHOMME lockup'))
for n in ['charcoal', 'offwhite', 'black', 'white']:
    out(f'01_logo/lockup/bonhomme-lockup-{n}-transparent.svg', svg_doc(round(LW, 1), round(LH, 1), P(LD, inks[n]), title='BONHOMME lockup'))
# primary on turquoise with clear space
out('01_logo/wordmark/bonhomme-wordmark-charcoal-on-turquoise.svg', svg_doc(round(WW + 2*pad, 1), round(WH + 2*pad, 1), f'<g transform="translate({pad},{pad})">{P(WD, C)}</g>', bg=T, title='BONHOMME primary logo'))
# tagline lockup: wordmark over "IN SERVICE OF ART." in Plex Mono, outlined
mono = font('IBMPlexMono-Bold.ttf')
tsize = 0.26 * WH
g, tw = set_line(mono, 'IN SERVICE OF ART.', tsize, tracking=0.12, y=cap_height(mono, tsize))
tg = union([pp_from_d(d) for _, d, _, _ in g]); tg, TW, TH = tight(tg)
tsc = (WW * 0.62) / TW
tag = union([wm, translate(tg, 4, WH + 0.55 * WH, tsc)]); tag, GW, GH = tight(tag)
for n, c in [('charcoal', C), ('offwhite', W), ('black', '#000000'), ('white', '#FFFFFF')]:
    out(f'01_logo/tagline/bonhomme-wordmark-tagline-{n}.svg', svg_doc(round(GW, 1), round(GH, 1), P(to_d(tag), c), title='BONHOMME, In service of art.'))

# pattern: the name as rhythm, offset rows
rows = ''
for i in range(9):
    rows += f'<path fill="{C if i % 4 else Y}" transform="translate({-((i * 380) % 1600)},{i * 1.18 * WH:.0f})" d="{WD}"/><path fill="{C if i % 4 else Y}" transform="translate({WW + 220 - ((i * 380) % 1600)},{i * 1.18 * WH:.0f})" d="{WD}"/>'
out('03_pattern/bonhomme-pattern-name-rows-on-turquoise.svg', svg_doc(5000, round(9 * 1.18 * WH), rows, bg=T))

P_ = json.load(open(os.path.join(FIN, 'paths.json')))
P_.update({'wm': WD, 'st': SD, 'bh': BD, 'seal': AVD, 'lock': LD, 'tag': to_d(tag)})
json.dump(P_, open(os.path.join(FIN, 'paths.json'), 'w'))
M = json.load(open(os.path.join(FIN, 'metrics.json')))
M.update({'WW': WW, 'WH': WH, 'SW': SW, 'SH': SH, 'BHW': BW, 'BHH': BHH, 'LW': LW, 'LH': LH, 'GW': GW, 'GH': GH, 'crop_s': cs})
json.dump(M, open(os.path.join(FIN, 'metrics.json'), 'w'))
print('ok', round(WW), round(WH), round(LW), round(LH))
