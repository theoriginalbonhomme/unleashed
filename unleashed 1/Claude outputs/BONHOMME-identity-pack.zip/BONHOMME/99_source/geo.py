"""True vector geometry for the final marks: unions, stencil cuts, bounds, SVG out."""
import pathops
from fontTools.svgLib.path import parse_path
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from lib import *

def pp_from_d(d, evenodd=False, transform=None):
    p = pathops.Path()
    pen = p.getPen()
    if transform:
        pen = TransformPen(pen, transform)
    parse_path(d, pen)
    if evenodd:
        p.fillType = pathops.FillType.EVEN_ODD
    return simplify_pp(p)

def simplify_pp(p):
    return pathops.simplify(p, fix_winding=True, keep_starting_points=False)

def union(paths):
    out = paths[0]
    for q in paths[1:]:
        out = pathops.op(out, q, pathops.PathOp.UNION)
    return out

def rect(x, y, w, h):
    p = pathops.Path(); pen = p.getPen()
    pen.moveTo((x, y)); pen.lineTo((x + w, y)); pen.lineTo((x + w, y + h)); pen.lineTo((x, y + h)); pen.closePath()
    return p

def minus(a, b):
    return pathops.op(a, b, pathops.PathOp.DIFFERENCE)

def inter(a, b):
    return pathops.op(a, b, pathops.PathOp.INTERSECTION)

def to_d(p, transform=None):
    pen = SVGPathPen(None)
    target = TransformPen(pen, transform) if transform else pen
    p.draw(target)
    return pen.getCommands()

def bounds(p):
    return p.bounds  # xmin, ymin, xmax, ymax

def wordmark_pp(fontfile, text, size, tracking, pair, wght=None):
    f = font(fontfile, wght=wght)
    glyphs, width = set_line(f, text, size, tracking=tracking, y=cap_height(f, size), pair=pair)
    return union([pp_from_d(d) for _, d, _, _ in glyphs]), width, cap_height(f, size)

def translate(p, dx, dy, s=1.0):
    return pp_from_d(to_d(p), transform=(s, 0, 0, s, dx, dy))
