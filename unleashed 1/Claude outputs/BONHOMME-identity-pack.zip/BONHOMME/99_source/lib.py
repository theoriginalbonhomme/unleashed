"""Shared helpers for the BONHOMME identity: palette, type-to-outline, portrait tracing."""
import io, os
import numpy as np
from PIL import Image, ImageFilter
import potrace
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.varLib import instancer

HERE = os.path.dirname(__file__)
FONTS = os.path.join(HERE, 'fonts')
SRC = '/root/.claude/uploads/37ea8de8-6b32-527e-8f0b-5b93401cd9e2/afb672f7-image.png'

PAL = {
    'turquoise': '#00B8C7',
    'charcoal': '#242323',
    'offwhite': '#F2F0E9',
    'orange': '#FF5A36',
}

_font_cache = {}
def font(name, wght=None, wdth=None):
    key = (name, wght, wdth)
    if key in _font_cache:
        return _font_cache[key]
    f = TTFont(os.path.join(FONTS, name))
    if 'fvar' in f:
        loc = {}
        axes = {a.axisTag for a in f['fvar'].axes}
        if wght and 'wght' in axes: loc['wght'] = wght
        if wdth and 'wdth' in axes: loc['wdth'] = wdth
        f = instancer.instantiateVariableFont(f, loc)
    _font_cache[key] = f
    return f

def glyph_path(f, ch, x, y, scale):
    """SVG path data for one character, baseline at y, placed at x (font units scaled)."""
    gs = f.getGlyphSet()
    gname = f.getBestCmap()[ord(ch)]
    pen = SVGPathPen(gs)
    tp = TransformPen(pen, (scale, 0, 0, -scale, x, y))
    gs[gname].draw(tp)
    adv = f['hmtx'][gname][0] * scale
    return pen.getCommands(), adv

def set_line(f, text, size, tracking=0.0, x=0.0, y=0.0, pair=None):
    """Lay out text as outlines. tracking in em; pair: {index: extra em after glyph i}.
    Returns (list of (char, path, x, adv)), total width."""
    upm = f['head'].unitsPerEm
    s = size / upm
    out = []
    cx = x
    for i, ch in enumerate(text):
        if ch == ' ':
            cx += size * 0.3
            continue
        d, adv = glyph_path(f, ch, cx, y, s)
        out.append((ch, d, cx, adv))
        cx += adv + tracking * size + (pair or {}).get(i, 0) * size
    width = cx - x - tracking * size - (pair or {}).get(len(text) - 1, 0) * size
    return out, width

def cap_height(f, size):
    os2 = f['OS/2']
    ch = getattr(os2, 'sCapHeight', 0) or int(f['head'].unitsPerEm * 0.7)
    return ch * size / f['head'].unitsPerEm

# ---------- portrait ----------
def load_ink(threshold=330):
    a = np.asarray(Image.open(SRC).convert('RGB')).astype(int)
    return a.sum(axis=2) < threshold          # True = ink

def trace(mask, turdsize=6, alphamax=1.0, opttol=0.4):
    """potrace traces False regions; pass the ink mask and get ink outlines."""
    path = potrace.Bitmap(~mask).trace(turdsize=turdsize, alphamax=alphamax,
                                       opticurve=True, opttolerance=opttol)
    parts = []
    for curve in path:
        s = curve.start_point
        d = [f"M{s.x:.1f},{s.y:.1f}"]
        for seg in curve.segments:
            if seg.is_corner:
                d.append(f"L{seg.c.x:.1f},{seg.c.y:.1f}L{seg.end_point.x:.1f},{seg.end_point.y:.1f}")
            else:
                d.append(f"C{seg.c1.x:.1f},{seg.c1.y:.1f} {seg.c2.x:.1f},{seg.c2.y:.1f} {seg.end_point.x:.1f},{seg.end_point.y:.1f}")
        d.append('Z')
        parts.append(''.join(d))
    return ' '.join(parts)

def to_img(mask):
    return Image.fromarray((~mask * 255).astype(np.uint8))

def from_img(img, t=128):
    return np.asarray(img.convert('L')) < t

def simplify(mask, blur=6, t=128):
    """Smooth the silhouette: blur then re-threshold."""
    img = to_img(mask).filter(ImageFilter.GaussianBlur(blur))
    return from_img(img, t)

def grow(mask, px):
    img = to_img(mask).filter(ImageFilter.MinFilter(px * 2 + 1))  # min on white-bg grows ink
    return from_img(img)

def svg_doc(w, h, body, bg=None, title=None):
    t = f'<title>{title}</title>' if title else ''
    b = f'<rect width="{w}" height="{h}" fill="{bg}"/>' if bg else ''
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}">{t}{b}{body}</svg>'
