"""Route B applications: release art, social, live, merch. The name leads; the face is the seal. Text outlined."""
import os, json, shutil
from lib import *
T, C, W, Y = '#00B8C7', '#242323', '#F2F0E9', '#FFE800'
FIN = os.path.join(HERE, 'final'); ROOT = os.path.join(FIN, 'BONHOMME')
for d in ['04_release', '05_social', '06_live', '07_merch']:
    p = os.path.join(ROOT, d)
    for f in os.listdir(p) if os.path.isdir(p) else []:
        if f.endswith('.svg'): os.remove(os.path.join(p, f))
for f in os.listdir(os.path.join(ROOT, '02_portrait')):
    if 'symbol' in f: os.remove(os.path.join(ROOT, '02_portrait', f))
M = json.load(open(os.path.join(FIN, 'metrics.json'))); D = json.load(open(os.path.join(FIN, 'paths.json')))
H, WW, WH, SW, SH, BW, BHH, LW, LH, AVS = M['H'], M['WW'], M['WH'], M['SW'], M['SH'], M['BHW'], M['BHH'], M['LW'], M['LH'], M['crop_s']
MONO = font('IBMPlexMono-Bold.ttf'); MONOR = font('IBMPlexMono-Regular.ttf')
def out(rel, svg):
    p = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'w').write(svg)
def text(s, x, y, size, fill, f=MONO, tracking=0.08, anchor='start'):
    glyphs, w = set_line(f, s, size, tracking=tracking)
    if anchor == 'end': x -= w
    if anchor == 'middle': x -= w / 2
    return f'<g fill="{fill}" transform="translate({x:.1f},{y:.1f})">' + ''.join(f'<path d="{d}"/>' for _, d, _, _ in glyphs) + '</g>'
def place(key, x, y, s, fill):
    return f'<path fill="{fill}" transform="translate({x:.1f},{y:.1f}) scale({s:.5f})" d="{D[key]}"/>'
def wm(x, y, w, fill): return place('wm', x, y, w / WW, fill)
def stk(x, y, w, fill): return place('st', x, y, w / SW, fill)
def bh(x, y, h, fill, right=False):
    s = h / BHH; return place('bh', x - BW * s if right else x, y, s, fill)
def seal(x, y, w, fill): return place('seal', x, y, w / AVS, fill)
def lock(x, y, w, fill): return place('lock', x, y, w / LW, fill)
svg = svg_doc

# ===== release art 3000 =====
S = 3000; m = 180
# BNHM 001 dub: charcoal, the name huge in turquoise, cropped off both edges, seal small
d1 = wm(-900, 900, 4800, T) + seal(m, m + 120, 420, W)
d1 += text('BNHM 001', S - m, m + 64, 64, W, anchor='end') + text('DEEP WATER EP', m, S - m, 72, W) + bh(S - m, S - m - 150, 150, W, right=True)
out('04_release/BNHM-001-dub-3000.svg', svg(S, S, d1, bg=C, title='BNHM 001, dub concept'))
# BNHM 002 acid: yellow, the stacked name giant and bleeding, fragmented face over it
d2 = stk(-160, 300, 3500, C) + place('frag', 1820, 1960, 1.0, C)
d2 += text('BNHM 002', m, m + 64, 64, C) + text('ACID SIGNAL', S - m, m + 64, 64, C, anchor='end')
out('04_release/BNHM-002-acid-3000.svg', svg(S, S, d2, bg=Y, title='BNHM 002, acid/techno concept'))
# BNHM 003 microhouse/IDM: off-white, a 9x9 field of tiny BH, one turquoise
d3 = f'<defs><path id="b" d="{D["bh"]}"/></defs>'
n = 9; cell = (S - 2 * m) / n; bhh = cell * 0.34; bs = bhh / BHH
for r in range(n):
    for c in range(n):
        x = m + c * cell + (cell - BW * bs) / 2; y = 360 + r * cell * 0.86
        d3 += f'<use href="#b" fill="{T if (r, c) == (5, 3) else C}" transform="translate({x:.1f},{y:.1f}) scale({bs:.5f})"/>'
d3 += text('BNHM 003', m, m + 64, 64, C) + text('MICRO / MACRO', S - m, m + 64, 64, C, anchor='end') + wm(m, S - m - WH * (1700 / WW), 1700, C)
out('04_release/BNHM-003-idm-3000.svg', svg(S, S, d3, bg=W, title='BNHM 003, microhouse/IDM concept'))
# template with guides
g = (f'<g id="guides" fill="none" stroke="{T}" stroke-width="4"><rect x="{m}" y="{m}" width="{S-2*m}" height="{S-2*m}"/>'
     f'<line x1="1500" y1="0" x2="1500" y2="3000"/><line x1="0" y1="1500" x2="3000" y2="1500"/></g>')
out('04_release/BNHM-template-3000-with-guides.svg', svg(S, S, '<g id="artwork"></g>' + text('BNHM 000', m, m + 64, 64, C) + text('RELEASE TITLE', m, S - m, 72, C) + bh(S - m, S - m - 150, 150, C, right=True) + g, bg=W, title='BONHOMME release template'))

# ===== social =====
avs = lambda w, bg, ink: svg(w, w, seal(0, 0, w, ink), bg=bg)
out('05_social/spotify-avatar-1500.svg', avs(1500, T, C)); out('05_social/soundcloud-avatar-1000.svg', avs(1000, T, C))
out('05_social/instagram-avatar-1080.svg', avs(1080, T, C)); out('05_social/youtube-avatar-800.svg', avs(800, T, C))
out('05_social/spotify-header-2660x1140.svg', svg(2660, 1140, place('master', 1460, -140, 1.38, W), bg=C))
yb = wm((2560 - 1400) / 2, (1440 - WH * 1400 / WW) / 2, 1400, C)
out('05_social/youtube-banner-2560x1440.svg', svg(2560, 1440, yb, bg=T))
out('05_social/youtube-banner-2560x1440-guides.svg', svg(2560, 1440, yb + f'<rect x="{(2560-1546)/2}" y="{(1440-423)/2}" width="1546" height="423" fill="none" stroke="{Y}" stroke-width="6"/>', bg=T))
yt = seal(700, 0, 720, C) + text('SMOOTH', 64, 300, 150, C, tracking=0) + text('SESSION', 64, 470, 150, C, tracking=0) + text('KAMPALA 14.10.26', 64, 620, 44, C)
out('05_social/youtube-thumbnail-1280x720.svg', svg(1280, 720, yt, bg=Y))
out('05_social/soundcloud-header-2480x520.svg', svg(2480, 520, lock((2480 - 1500) / 2, (520 - LH * 1500 / LW) / 2, 1500, C), bg=T))
ig = place('master', 200, 40, 860 / H, C) + text('DAY 00.00', 72, 1110, 72, C, tracking=0.02) + text('CITY · VENUE', 72, 1180, 40, C) + wm(72, 1220, 936, C)
out('05_social/instagram-post-1080x1350-event.svg', svg(1080, 1350, ig, bg=Y))
stv = stk(80, 260, 920, C) + text('NEW MIX · OUT NOW ON MIXCLOUD', 80, 760, 36, C) + place('frag', -60, 820, 1.2, C)
out('05_social/instagram-story-1080x1920.svg', svg(1080, 1920, stv, bg=T))
out('05_social/instagram-story-1080x1920-guides.svg', svg(1080, 1920, stv + f'<rect width="1080" height="150" fill="{Y}" opacity="0.5"/><rect y="1670" width="1080" height="250" fill="{Y}" opacity="0.5"/>', bg=T))
pw, ph = 420, 594
po = stk(-14, 24, 470, C) + place('master', 150, 210, 300 / H, C)
for i in range(3):
    yy = 520 + i * 22
    po += text('00.00', 20, yy, 13, C) + text('CITY', 100, yy, 13, C) + text('VENUE', 400, yy, 10, C, f=MONOR, anchor='end')
po += text('IN SERVICE OF ART.', 20, 584, 9, C)
out('05_social/tour-poster-A2-420x594mm.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {pw} {ph}" width="{pw}mm" height="{ph}mm"><rect width="{pw}" height="{ph}" fill="{T}"/>{po}</svg>')

# ===== live keyframes =====
out('06_live/keyframe-01-name.svg', svg(1920, 1080, wm(160, (1080 - WH * 1600 / WW) / 2, 1600, W), bg=C))
out('06_live/keyframe-02-crop.svg', svg(1920, 1080, wm(-1400, 120, 5200, T), bg=C))
k3 = ''.join(wm(-300 - (i * 260) % 900, 30 + i * 150, 2700, Y if i == 3 else W) for i in range(7))
out('06_live/keyframe-03-repeat.svg', svg(1920, 1080, k3, bg=C))
out('06_live/keyframe-04-face.svg', svg(1920, 1080, seal(420, 0, 1080, C), bg=T))

# ===== merch (real units) =====
out('07_merch/tshirt-front-1ink-12x4in.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 4" width="12in" height="4in">{wm(0, (4 - WH * 12 / WW) / 2, 12, C)}</svg>')
out('07_merch/hoodie-back-1ink-14x14in.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14" width="14in" height="14in">{stk(0, 0, 14, C)}{seal(4, 6.8, 6, C)}</svg>')
out('07_merch/cap-embroidery-bh-2.5in.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2.5 {2.5*BHH/BW:.3f}" width="2.5in" height="{2.5*BHH/BW:.3f}in">{bh(0, 0, 2.5 * BHH / BW, C)}</svg>')
lab = (f'<circle cx="50" cy="50" r="50" fill="{Y}"/>' + bh(50 - BW * (16 / BHH) / 2, 22, 16, C) + text('BNHM 002', 50, 70, 5, C, anchor='middle')
       + text('SIDE A · 33 RPM', 50, 78, 3.4, C, f=MONOR, anchor='middle') + '<circle cx="50" cy="50" r="3.62" fill="#FFFFFF" stroke="#242323" stroke-width="0.2"/>')
out('07_merch/vinyl-label-100mm.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100mm" height="100mm">{lab}</svg>')
stk_ = f'<circle cx="37.5" cy="37.5" r="37.5" fill="{T}"/>' + seal(7.5, 4, 60, C) + '<circle id="cutline" cx="37.5" cy="37.5" r="37.5" fill="none" stroke="#FF00FF" stroke-width="0.25"/>'
out('07_merch/sticker-75mm-diecut.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 75 75" width="75mm" height="75mm">{stk_}</svg>')
sten = f'<path fill="none" stroke="#FF0000" stroke-width="0.2" transform="translate(13.5,60) scale({270/H:.5f})" d="{D["stencil"]}"/>'
out('07_merch/physical-stencil-A3-lasercut.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 297 420" width="297mm" height="420mm"><rect width="297" height="420" fill="none" stroke="#000" stroke-width="0.2"/>{sten}</svg>')
out('07_merch/stage-banner-6000x2000mm.svg', f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6000 2000" width="6000mm" height="2000mm"><rect width="6000" height="2000" fill="{T}"/>{lock(600, (2000 - LH * 4800 / LW) / 2, 4800, C)}</svg>')
print('ok')
