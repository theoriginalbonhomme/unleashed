"""Route B mockups and incorrect-use examples."""
import os, json, re, shutil
import numpy as np
from lib import *
T, C, W, Y = '#00B8C7', '#242323', '#F2F0E9', '#FFE800'
FIN = os.path.join(HERE, 'final'); OUT = os.path.join(FIN, 'mockups')
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
M = json.load(open(os.path.join(FIN, 'metrics.json'))); D = json.load(open(os.path.join(FIN, 'paths.json')))
WW, WH, LW, LH, BW, BHH, AVS, SW = M['WW'], M['WH'], M['LW'], M['LH'], M['BHW'], M['BHH'], M['crop_s'], M['SW']
def save(n, s): open(os.path.join(OUT, n), 'w').write(s)
def place(k, x, y, s, fill, extra=''): return f'<path fill="{fill}" {extra} transform="translate({x:.1f},{y:.1f}) scale({s:.5f})" d="{D[k]}"/>'
def inner(p): s = open(p).read(); s = re.sub(r'^<svg[^>]*>', '', s); return re.sub(r'</svg>$', '', s)

tee = 'M300,80 L420,40 Q500,90 580,40 L700,80 L860,220 L770,330 L700,280 L700,940 L300,940 L300,280 L230,330 L140,220 Z'
save('mock-tee.svg', svg_doc(1000, 1000, f'<path d="{tee}" fill="{T}"/>' + place('wm', 345, 300, 310 / WW, C) + place('seal', 600, 850, 60 / AVS, C), bg=W))
cap = f'<path d="M180,560 Q200,250 500,230 Q800,250 820,560 Z" fill="{C}"/><path d="M150,560 Q500,520 900,600 Q880,660 520,640 Q260,630 150,600 Z" fill="#1A1919"/>'
save('mock-cap.svg', svg_doc(1000, 1000, cap + place('bh', 410, 360, 180 / BW, W), bg=Y))
art = inner(os.path.join(FIN, 'BONHOMME/04_release/BNHM-002-acid-3000.svg'))
vin = (f'<circle cx="640" cy="500" r="360" fill="#141414"/>' + ''.join(f'<circle cx="640" cy="500" r="{r}" fill="none" stroke="#2C2C2C" stroke-width="2"/>' for r in range(160, 356, 14))
       + f'<svg x="80" y="140" width="720" height="720" viewBox="0 0 3000 3000">{art}</svg>')
save('mock-vinyl.svg', svg_doc(1100, 1000, vin, bg=W))
save('mock-sticker.svg', svg_doc(1000, 1000, '<g transform="rotate(-8 500 500)"><circle cx="500" cy="500" r="300" fill="#FFFFFF"/><circle cx="500" cy="500" r="284" fill="#00B8C7"/>' + place('seal', 260, 240, 480 / AVS, C) + '</g>', bg=C))
st = f'<rect width="1920" height="1080" fill="#141414"/><rect x="160" y="80" width="1600" height="533" fill="{T}"/>' + place('lock', 360, 80 + (533 - LH * 1200 / LW) / 2, 1200 / LW, C)
st += '<rect y="820" width="1920" height="260" fill="#0C0C0C"/><rect x="760" y="700" width="400" height="120" fill="#2A2A2A"/>'
save('mock-stage.svg', svg_doc(1920, 1080, st))

w, h = 600, 360; lw = 500; ly = (h - LH * lw / LW) / 2
def tile(n, body, bg): save(f'dont-{n}.svg', svg_doc(w, h, body, bg=bg))
L = lambda fill, extra='': place('lock', 50, ly, lw / LW, fill, extra)
tile('stretch', f'<g transform="translate(0,{-ly*0.9:.1f}) scale(1,1.9)">{L(C)}</g>', T)
tile('recolour', L('#E0479E'), T)
f = font('ArchivoBlack-Regular.ttf'); g, gw = set_line(f, 'BONHOMME', 66, tracking=0.04, y=cap_height(f, 66))
tile('retyped', f'<g fill="{C}" transform="translate({(w - gw) / 2:.1f},150)">' + ''.join(f'<path d="{d}"/>' for _, d, _, _ in g) + '</g>', T)
tile('effects', '<defs><filter id="sh"><feDropShadow dx="8" dy="8" stdDeviation="4" flood-color="#000" flood-opacity="0.6"/></filter></defs>' + L(C, 'filter="url(#sh)" stroke="#FFE800" stroke-width="40"'), T)
tile('lowcontrast', L(W), T)
rng = np.random.default_rng(5)
busy = ''.join(f'<rect x="{int(rng.integers(0,600))}" y="{int(rng.integers(0,360))}" width="{int(rng.integers(20,160))}" height="{int(rng.integers(10,90))}" fill="{rng.choice(["#E0479E","#3B5BDB","#FFE800","#00B8C7","#7A5C3E"])}"/>' for _ in range(90))
tile('busy', busy + L(C), '#8A8A8A')
shutil.rmtree(os.path.join(FIN, 'BONHOMME', '08_mockups'), ignore_errors=True); shutil.copytree(OUT, os.path.join(FIN, 'BONHOMME', '08_mockups'))
print('ok')
