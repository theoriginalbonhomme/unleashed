// Runs when Bonhomme adds the "approved" label to an issue.
// Reads the issue form, adds the entry to the right data file, then comments and closes the issue.

const FIELD_MAP = {
  artist: {
    file: 'data/artists.json',
    labels: {
      'Artist name': 'name', 'What you do': 'roles', 'Where you are (a city, or "on the road")': 'based',
      'Short bio': 'bio', 'Who you want to collaborate with': 'looking_for',
      'Your links': 'links', 'Public contact': 'contact'
    }
  },
  release: {
    file: 'data/releases.json',
    labels: {
      'Title': 'title', 'Artists': 'artists', 'Type': 'type', 'Link to listen': 'url',
      'Free download link (optional)': 'download', 'BPM (optional)': 'bpm',
      'Genre (optional)': 'genre', 'Release date (YYYY-MM-DD)': 'date'
    }
  },
  collab: {
    file: 'data/collabs.json',
    labels: {
      'Title': 'title', 'Your Unleashed profile name': 'by', 'What you have': 'have',
      'Who you need': 'need', 'Link to a sketch (optional)': 'link'
    }
  }
};

function parseForm(body) {
  const out = {};
  const parts = (body || '').split(/^### /m).slice(1);
  for (const part of parts) {
    const nl = part.indexOf('\n');
    const label = part.slice(0, nl).trim();
    let value = part.slice(nl + 1).trim();
    if (value === '_No response_' || value === 'None') value = '';
    out[label] = value;
  }
  return out;
}

const slugify = s => String(s).toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 40) || 'item';
const isUrl = s => /^https?:\/\/[^\s]+$/i.test(s || '');
const list = s => String(s || '').split(',').map(x => x.trim()).filter(Boolean);
const clip = (s, n) => String(s || '').slice(0, n);
const today = () => new Date().toISOString().slice(0, 10);

module.exports = async ({ github, context, core }) => {
  const issue = context.payload.issue;
  const names = issue.labels.map(l => l.name);
  const kind = ['artist', 'release', 'collab'].find(k => names.includes(k));
  if (!kind) { core.info('No artist/release/collab label, nothing to do.'); return; }

  const spec = FIELD_MAP[kind];
  const raw = parseForm(issue.body);
  const f = {};
  for (const [label, key] of Object.entries(spec.labels)) f[key] = raw[label] || '';

  const { owner, repo } = context.repo;
  const getJson = async path => {
    const res = await github.rest.repos.getContent({ owner, repo, path });
    return { sha: res.data.sha, data: JSON.parse(Buffer.from(res.data.content, 'base64').toString('utf8')) };
  };

  const artistsFile = await getJson('data/artists.json');
  const findArtist = name => {
    const n = name.toLowerCase();
    const a = artistsFile.data.find(x => x.slug === n || x.name.toLowerCase() === n || (x.aliases || []).some(al => al.toLowerCase() === n));
    return a ? a.slug : name;
  };

  const target = kind === 'artist' ? artistsFile : await getJson(spec.file);
  let entry, label;

  if (kind === 'artist') {
    let slug = slugify(f.name);
    while (target.data.some(a => a.slug === slug)) slug += '-' + Math.floor(Math.random() * 90 + 10);
    entry = {
      slug, name: clip(f.name, 60), aliases: [], roles: list(f.roles), based: clip(f.based, 80),
      bio: clip(f.bio, 600), looking_for: clip(f.looking_for, 400),
      links: f.links.split('\n').map(x => x.trim()).filter(isUrl).slice(0, 8),
      contact: clip(f.contact, 120), open_to_collab: true, github: issue.user.login
    };
    label = `Profile for ${entry.name} is live: https://${owner}.github.io/#artist-${slug}`;
  } else if (kind === 'release') {
    if (!isUrl(f.url)) { core.setFailed('The listen link is not a valid URL.'); return; }
    entry = {
      id: slugify(f.title) + '-' + issue.number, title: clip(f.title, 120),
      artists: list(f.artists).map(findArtist), alias: '', type: f.type || 'Track',
      date: /^\d{4}-\d{2}-\d{2}$/.test(f.date) ? f.date : today(), length: '',
      bpm: clip(f.bpm.replace(/[^\d.]/g, ''), 6), genre: clip(f.genre, 40), url: f.url,
      download: isUrl(f.download) ? f.download : '', original_lost: false
    };
    target.data.unshift(entry);
    label = `"${entry.title}" is live in the library.`;
  } else {
    entry = {
      id: slugify(f.title) + '-' + issue.number, title: clip(f.title, 120), by: findArtist(f.by),
      date: today(), have: clip(f.have, 600), need: list(f.need), link: isUrl(f.link) ? f.link : '', status: 'Open'
    };
    target.data.unshift(entry);
    label = `Collab call "${entry.title}" is live on the board.`;
  }
  if (kind === 'artist') target.data.push(entry);

  await github.rest.repos.createOrUpdateFileContents({
    owner, repo, path: spec.file, sha: target.sha,
    message: `Approve ${kind}: ${entry.name || entry.title} (#${issue.number})`,
    content: Buffer.from(JSON.stringify(target.data, null, 2) + '\n').toString('base64')
  });
  await github.rest.issues.createComment({ owner, repo, issue_number: issue.number, body: `Approved. ${label} The site updates in about a minute.` });
  await github.rest.issues.update({ owner, repo, issue_number: issue.number, state: 'closed' });
};
